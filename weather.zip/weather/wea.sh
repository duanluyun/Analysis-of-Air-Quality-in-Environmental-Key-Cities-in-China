/home/sam/local/spark-2.3.0-bin-2.6.0-cdh5.7.0/bin/spark-submit --master local[2] --jars ./elasticsearch-spark-20_2.11-6.3.0.jar ./project.py 
